# Outlook → Supabase feed (runs on its own, every 5 minutes)

## 1. Microsoft: let the feed read the bookings mailbox (10 min, admin account)
1. portal.azure.com → **Microsoft Entra ID → App registrations → New registration**
   Name: `Paint Patch HQ feed` · Single tenant · no redirect URI → Register.
2. Copy **Application (client) ID** and **Directory (tenant) ID**.
3. **Certificates & secrets → New client secret** (24 months) → copy the **Value**.
4. **API permissions → Add → Microsoft Graph → Application permissions → Mail.Read** → Add →
   **Grant admin consent**. (Read-only: the feed never sends, drafts or deletes.)
5. Recommended: limit the app to the bookings mailbox only (Exchange "Application access policy"
   or RBAC for Applications) so it can't read other staff mailboxes.

## 2. Supabase: SQL (SQL Editor, in order)
1. `paint_patch_hq.sql`  2. `hq_complaints_bookings.sql`

## 3. Supabase: deploy the function
1. **Edge Functions → Deploy a new function → Via Editor**, name it exactly `outlook-feed`.
2. Paste `functions/outlook-feed/index.ts` → Deploy.
3. **Edge Functions → Secrets** → add:
   `MS_TENANT_ID`, `MS_CLIENT_ID`, `MS_CLIENT_SECRET`, `MS_MAILBOX` = bookings@thepaintpatch.com,
   `CRON_SECRET` = any long random text.

## 4. Supabase: schedule it
Edit the 3 placeholders in `hq_outlook_feed.sql`, run it. First run reads the last 60 days.

## 5. Check
`select status, last_sync, note from hq_integrations where id in ('outlook','roller');`
"Feed OK" with counts = working. "needs_attention" shows the reason.
